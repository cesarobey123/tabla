//(c) Mariano Gaite, 2004
var huec0_rsp= new Array();
huec0_rsp[0]=String.fromCharCode(97,116,243,109,105,99,111);
var huec1_rsp= new Array();
huec1_rsp[0]=String.fromCharCode(112,101,114,237,111,100,111,115);
var huec2_rsp= new Array();
huec2_rsp[0]=String.fromCharCode(103,114,117,112,111,115);
var huec3_rsp= new Array();
huec3_rsp[0]=String.fromCharCode(115,105,109,105,108,97,114);
huec3_rsp[1]=String.fromCharCode(112,97,114,101,99,105,100,111);
huec3_rsp[2]=String.fromCharCode(115,101,109,101,106,97,110,116,101);

var huec0_sz=1, huec1_sz=1, huec2_sz=1, huec3_sz=1;
for (i in huec0_rsp){
  if (huec0_rsp[i].length>huec0_sz) huec0_sz=huec0_rsp[i].length;
}
for (i in huec1_rsp){
  if (huec1_rsp[i].length>huec1_sz) huec1_sz=huec1_rsp[i].length;
}
for (i in huec2_rsp){
  if (huec2_rsp[i].length>huec2_sz) huec2_sz=huec2_rsp[i].length;
}
for (i in huec3_rsp){
  if (huec3_rsp[i].length>huec3_sz) huec3_sz=huec3_rsp[i].length;
}


var v_huecos=new Array();

function registrar_v() {
   for (i=0; i<4; i++) {
   v_huecos[i]=eval("document.formtxt.hueco"+i+".value");
   v_huecos[i]=v_huecos[i].toLowerCase();
     while (v_huecos[i].indexOf (" ")==0) {
     v_huecos[i]=v_huecos[i].substr(1);
     }
     while (v_huecos[i].indexOf (" ")!=-1) {
     var pos=v_huecos[i].indexOf (" ");
     v_huecos[i]=v_huecos[i].substring(0,pos)+v_huecos[i].substr(pos+1);
     }
   }
}

var acierto=new Array(4);

function revisar_txt() {
 for (j=0; j<4; j++){
   for (i in eval("huec"+j+"_rsp")){
     if (v_huecos[j]==eval("huec"+j+"_rsp["+i+"]")) {
     acierto[j]=true;
     break;
     }
     else acierto[j]=false;
   }
 }
}

var desc_pist=new Array(0,0,0,0);

function crea_pista() {
	var posicion;
	for (i=0; i<acierto.length; i++) {
		if (acierto[i]==false){
			posicion=i;
			break;
		}
	}
	if(posicion==null) return;
	var pista="";
	var text_pista="";
	var pt_letra=0;

 switch (posicion) {
  case 0:
    for (i in huec0_rsp){
      if (huec0_rsp[i].indexOf(v_huecos[0])==0 && v_huecos[0].length<huec0_rsp[i].length) {
      pista=huec0_rsp[i].substr(v_huecos[0].length,1);
      text_pista=v_huecos[0]+pista;
      pt_letra=1/huec0_rsp[i].length;
      break;
      }
      else {
      pista=huec0_rsp[0].substr(0,1);
      text_pista=pista;
      pt_letra=1/huec0_rsp[0].length;
      }
    }
  document.formtxt.hueco0.value=text_pista;
  desc_pist[0]+=pt_letra;
  break;

  case 1:
    for (i in huec1_rsp){
      if (huec1_rsp[i].indexOf(v_huecos[1])==0 && v_huecos[1].length<huec1_rsp[i].length) {
      pista=huec1_rsp[i].substr(v_huecos[1].length,1);
      text_pista=v_huecos[1]+pista;
      pt_letra=1/huec1_rsp[i].length;
      break;
      }
      else {
      pista=huec1_rsp[0].substr(0,1);
      text_pista=pista;
      pt_letra=1/huec1_rsp[0].length;
      }
    }
  document.formtxt.hueco1.value=text_pista;
  desc_pist[1]+=pt_letra;
  break;

  case 2:
    for (i in huec2_rsp){
      if (huec2_rsp[i].indexOf(v_huecos[2])==0 && v_huecos[2].length<huec2_rsp[i].length) {
      pista=huec2_rsp[i].substr(v_huecos[2].length,1);
      text_pista=v_huecos[2]+pista;
      pt_letra=1/huec2_rsp[i].length;
      break;
      }
      else {
      pista=huec2_rsp[0].substr(0,1);
      text_pista=pista;
      pt_letra=1/huec2_rsp[0].length;
      }
    }
  document.formtxt.hueco2.value=text_pista;
  desc_pist[2]+=pt_letra;
  break;

  case 3:
    for (i in huec3_rsp){
      if (huec3_rsp[i].indexOf(v_huecos[3])==0 && v_huecos[3].length<huec3_rsp[i].length) {
      pista=huec3_rsp[i].substr(v_huecos[3].length,1);
      text_pista=v_huecos[3]+pista;
      pt_letra=1/huec3_rsp[i].length;
      break;
      }
      else {
      pista=huec3_rsp[0].substr(0,1);
      text_pista=pista;
      pt_letra=1/huec3_rsp[0].length;
      }
    }
  document.formtxt.hueco3.value=text_pista;
  desc_pist[3]+=pt_letra;
  break;
 }
}

var text_campo=new Array("","","","");

function calc_punt() {
var pt_maxima=100;
var pt_campo=new Array();
var pt_total=0;
  for (i in acierto) {
   if (acierto[i]==true){
    if (desc_pist[i]>1) desc_pist[i]=1;
    pt_campo[i]=(pt_maxima/acierto.length)*(1-desc_pist[i]);
    pt_total+=pt_campo[i];
    text_campo[i]=v_huecos[i];
    }
  eval("document.formtxt.hueco"+i+".value=text_campo["+i+"]")
  }
pt_total=Math.round(pt_total);
alert("Has obtenido una puntuaci�n del: "+pt_total+"%");
}

function pon_pista(){
  registrar_v();
  revisar_txt();
  crea_pista();
}

function pon_nota(){
  registrar_v();
  revisar_txt();
  calc_punt();
}
