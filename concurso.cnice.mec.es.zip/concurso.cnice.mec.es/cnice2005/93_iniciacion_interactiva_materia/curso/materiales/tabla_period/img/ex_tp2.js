//(c) Mariano Gaite, 2004
var calificacion=0;
function nota()
{
calificacion=0;
incorrectas="";
contestadas=0;

//la iteraci�n del bucle for es solo para los �tems del formulario basados en botones de radio
//por eso resto a la longitud (length-7) dos de los botones reset y 5 de la cuesti�n basada en marcas.

for (i=0; i<document.examen.length-6; i++)
  {
  if (document.examen[i].checked)
    {    
    contestadas++;
    if (document.examen[i].value=="1") calificacion++;
    if (document.examen[i].value!="1")
      {
      incorrectas+=document.examen[i].name.substr(2,2)+", ";
      }
    }
  }

with(document.examen) {
if(q51.checked || q52.checked || q53.checked || q54.checked){
  contestadas++;
//l�nea para comprobar que se han marcado los cuadros (checkboxes) correctos.
//Hay que cambiarla en cuestiones nuevas que se introduzca de este tipo (checkbox)
  if(q51.checked && !q52.checked && !q53.checked && q54.checked)
  calificacion++;
else incorrectas+=q51.value.substr(2,2)+", ";
  }
}
error=contestadas-calificacion;
mensaje=contestadas+" preguntas contestadas de 5:\n  "+calificacion+" preguntas acertadas.\n  "+error+" preguntas no acertadas: "+incorrectas+"\n\nHas obtenido una calificaci�n de "+calificacion*2+" ptos.";
alert(mensaje);
}
